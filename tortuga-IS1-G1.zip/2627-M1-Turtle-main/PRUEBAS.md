# Comprobaciones visibles de M1

Ejecuta el juego después de cada cambio y anota el resultado:

- ambas velocidades positivas: termina y anuncia una ganadora;
- roja más rápida: gana la roja;
- azul más rápida: gana la azul;
- velocidades iguales: anuncia un empate (no puede ganar siempre la roja);
- alguna velocidad igual a cero o negativa: muestra el aviso y no inicia la carrera;
- antes de ejecutar, puedes justificar tu predicción usando las velocidades.

No se considera terminado si sólo funciona con una combinación concreta.

-Anotaciones:
1º: cambio las velocidades, las tortugas vuelven al inicio pero no avanzan
2º: hago los TODO 2 y 3, las tortugas avanzan bien y gana la que mas velocidad tiene, cuando pongo un numero <= 0 no arranca el programa y,  cuando tienen la misma velocidad,muestra que gana la roja, me percato que tengo los condicionales en el orden: gana roja, gana azul y empate.
3º: pongo el empate ante los otros dos, resultado: cuando tienen la misma velocidad muestra empate, si la roja tiene mas, gana esta, y si la azul supera en velocidad a la roja, gana la azul.

-asi el codigo estaria resuelto

-no he hecho uso de IA, sin embargo me han ayudado mis compañeros a resolverlo y el copilot de python cambio dos lineas erroneas